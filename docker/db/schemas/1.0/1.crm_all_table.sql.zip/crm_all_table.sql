SET foreign_key_checks = 0;

/** モジュール情報テーブルを作成(G-NEXT管理者のみ設定できる) */
DROP TABLE IF EXISTS `crm_system_module`;
CREATE TABLE `crm_system_module` (
  `module_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'モジュールID',
  `module_name` varchar(45) NOT NULL DEFAULT '' COMMENT 'モジュール名',
  `module_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='モジュール情報';
insert into crm_system_module(module_name,creator_id,created_time) values ('会社管理',1,now());
insert into crm_system_module(module_name,creator_id,created_time) values ('ロール管理',1,now());
insert into crm_system_module(module_name,creator_id,created_time) values ('受付情報',1,now());
insert into crm_system_module(module_name,creator_id,created_time) values ('メンテ',1,now());
insert into crm_system_module(module_name,creator_id,created_time) values ('メール',1,now());
insert into crm_system_module(module_name,creator_id,created_time) values ('メッセジャー',1,now());
insert into crm_system_module(module_name,creator_id,created_time) values ('WebRTC',1,now());


/** 会社情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_company`;
CREATE TABLE `crm_company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '会社ID',
  `company_name` varchar(80) NOT NULL DEFAULT '' COMMENT '名前',
  `company_post` varchar(8) DEFAULT NULL COMMENT '郵便番号',
  `company_city` int(11) DEFAULT NULL COMMENT '都道府県',
  `company_address` varchar(150) DEFAULT NULL COMMENT '住所',
  `company_address_kana` varchar(200) DEFAULT NULL COMMENT '住所カナ',
  `company_logo` varchar(150) DEFAULT NULL COMMENT 'ロゴ',
  `company_home_page` varchar(150) DEFAULT NULL COMMENT 'ホームページ',
  `company_copy_right` varchar(150) DEFAULT NULL COMMENT 'Copyright',
  `company_layout` varchar(20) DEFAULT NULL COMMENT 'システムレイアウト',
  `company_global_ip` varchar(120) DEFAULT NULL COMMENT '会社グロバールIP',
  `company_global_group_flag` tinyint(4) DEFAULT '0' COMMENT '会社グルーブフラグ、１は有効',
  `company_union_key` varchar(100) DEFAULT '0' COMMENT 'グルーブ会社IDキー',
  `company_business_flag` tinyint(4) NOT NULL DEFAULT '1' COMMENT '業界フラグ「１は相談室、２店舗、３保険、。。。」',
  `company_memo` varchar(500) DEFAULT NULL COMMENT 'メモ',
  `company_global_locale` tinyint(4) DEFAULT NULL COMMENT '１は他言語使用可能',
  `company_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`company_id`),
  KEY `company_global_ip` (`company_global_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会社情報';
insert into crm_company(company_name,creator_id,created_time) values ('ジーネクスト',1,now());
insert into crm_company(company_name,creator_id,created_time) values ('ベトナム',1,now());
insert into crm_company(company_name,creator_id,created_time) values ('ミャンマー',1,now());

/** 会社やメンバー「メール、TEL、FAX」情報を作成 */
DROP TABLE IF EXISTS `crm_company_target_info`;
CREATE TABLE `crm_company_target_info` (
  `target_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'タゲットID',
  `company_target` tinyint(4) NOT NULL DEFAULT '0' COMMENT '「１は会社、２はメンバー」',
  `company_target_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社IDまたはメンバーID',
  `company_flag_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '「１はメール、２は電話番号、３は携帯番号、４はFAX」',
  `company_target_data` varchar(120) DEFAULT NULL COMMENT '各タイプのデータ',
  `company_target_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`target_id`),
  INDEX (company_target,company_target_id,company_flag_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会社やメンバー「メール、TEL、MOBILE、FAX」情報';

/** グルーブ会社にアクセス情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_union_company_rel`;
CREATE TABLE `crm_union_company_rel` (
  `company_union_key` varchar(100) NOT NULL DEFAULT '' COMMENT 'グルーブ会社IDキー',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  PRIMARY KEY (`company_union_key`,`company_id`),
  KEY `fk_crm_union_company_rel_company_idx` (`company_id`),
  CONSTRAINT `fk_crm_union_company_rel_company` FOREIGN KEY (`company_id`) REFERENCES `crm_company` (`company_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='グルーブ会社にアクセス情報';
insert into crm_union_company_rel(company_union_key,company_id) values ('20160913170000',1);
insert into crm_union_company_rel(company_union_key,company_id) values ('20160913170000',2);

/** 会社使用可能モジュール情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_company_module_rel`;
CREATE TABLE `crm_company_module_rel` (
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `module_id` int(11) NOT NULL DEFAULT '0' COMMENT 'モジュールID',
  PRIMARY KEY (`company_id`,`module_id`),
  KEY `fk_crm_company_module_rel_module_idx` (`module_id`),
  CONSTRAINT `fk_crm_company_module_rel_company` FOREIGN KEY (`company_id`) REFERENCES `crm_company` (`company_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_company_module_rel_module` FOREIGN KEY (`module_id`) REFERENCES `crm_system_module` (`module_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会社使用可能モジュール情報';

/** グループ情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_group`;
CREATE TABLE `crm_group` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'グループID',
  `group_name` varchar(45) NOT NULL DEFAULT '' COMMENT '名前',
  `group_parent_id` int(11) DEFAULT NULL COMMENT 'グループ親ID',
  `group_tree_id` varchar(500) DEFAULT NULL COMMENT 'グループツリー',
  `group_order` int(11) DEFAULT NULL COMMENT '表示順',
  `group_memo` varchar(500) DEFAULT NULL COMMENT 'メモ',
  `group_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`group_id`,`company_id`),
  KEY `cons_company` (`company_id`) USING BTREE,
  CONSTRAINT `cons_company` FOREIGN KEY (`company_id`) REFERENCES `crm_company` (`company_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='グループ情報';
insert into crm_group(group_name,company_id,creator_id,created_time) values ('開発部',1,1,now());
insert into crm_group(group_name,company_id,creator_id,created_time) values ('開発部',2,1,now());
insert into crm_group(group_name,company_id,creator_id,created_time) values ('開発部',3,1,now());

/** メンバー情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_member`;
CREATE TABLE `crm_member` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'メンバーID',
  `member_login_id` varchar(30) DEFAULT NULL COMMENT 'ログインID',
  `member_code` varchar(30) DEFAULT NULL COMMENT 'メンバーコード',
  `member_password` varchar(60) DEFAULT NULL COMMENT 'パスワード',
  `member_name_first` varchar(70) NOT NULL DEFAULT '' COMMENT '名前１',
  `member_name_last` varchar(70) NOT NULL DEFAULT '' COMMENT '名前２',
  `member_kana_first` varchar(70) DEFAULT NULL COMMENT 'カナ１',
  `member_kana_last` varchar(70) DEFAULT NULL COMMENT 'カナ２',
  `member_post` varchar(8) DEFAULT '' COMMENT '郵便番号',
  `member_city` int(11) DEFAULT NULL COMMENT '都道府県',
  `member_address` varchar(150) DEFAULT NULL COMMENT '住所',
  `member_address_kana` varchar(200) DEFAULT NULL COMMENT '住所カナ',
  `member_image` varchar(150) DEFAULT NULL COMMENT 'メンバー写真',
  `member_layout` varchar(20) DEFAULT NULL COMMENT 'システムレイアウト',
  `member_firewall` tinyint(4) DEFAULT '0' COMMENT 'FW許可、会社情報にGrobalIP設定した場合、１は外から接続NG',
  `member_global_flag` tinyint(4) DEFAULT '0' COMMENT 'グールブ会社データ使用フラグ',
  `member_manager_flag` tinyint(4) DEFAULT '0' COMMENT '１は管理者、０は一般メンバー',
  `member_global_locale` tinyint(4) DEFAULT NULL COMMENT '１は他言語使用可能',
  `member_memo` varchar(500) DEFAULT NULL COMMENT 'メモ',
  `member_order` int(11) DEFAULT NULL COMMENT '表示順',
  `member_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `group_id` int(11) NOT NULL DEFAULT '0' COMMENT 'グルーブID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`member_id`,`group_id`),
  UNIQUE KEY `member_login_id_UNIQUE` (`member_login_id`),
  KEY `cons_group_user` (`group_id`) USING BTREE,
  CONSTRAINT `cons_group_user` FOREIGN KEY (`group_id`) REFERENCES `crm_group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='メンバー情報';
insert into crm_member(member_login_id,member_password,member_name_first,member_name_last,group_id,creator_id,created_time) values ('admin','admin','ぐえん','う゛ぁんふぉん',1,1,now());
insert into crm_member(member_login_id,member_password,member_name_first,member_name_last,group_id,creator_id,created_time) values ('admin1','admin1','ぐえん','う゛ぁんふぉん1',2,1,now());
insert into crm_member(member_login_id,member_password,member_name_first,member_name_last,group_id,creator_id,created_time) values ('admin2','admin2','ぐえん','う゛ぁんふぉん2',3,1,now());
insert into crm_member(member_login_id,member_password,member_name_first,member_name_last,group_id,creator_id,created_time) values ('admin3','admin3','ぐえん','う゛ぁんふぉん',1,1,now());

/** 複数グルーブにアクセス情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_multiple_member_group_rel`;
CREATE TABLE `crm_multiple_member_group_rel` (
  `member_id` int(11) NOT NULL DEFAULT '0' COMMENT 'メンバーID',
  `group_id` int(11) NOT NULL DEFAULT '0' COMMENT 'グルーブID',
  PRIMARY KEY (`member_id`,`group_id`),
  CONSTRAINT `fk_crm_multiple_member_group_rel_member` FOREIGN KEY (`member_id`) REFERENCES `crm_member` (`member_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_multiple_member_group_rel_group` FOREIGN KEY (`group_id`) REFERENCES `crm_group` (`group_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='メンバー複数グルーブにアクセス情報';

/** システム全て画面情報テーブルを作成（ロードする際に、プロパティ） */
DROP TABLE IF EXISTS `crm_page`;
CREATE TABLE `crm_page` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'メンバーID',
  `page_en_name` varchar(45) NOT NULL DEFAULT '' COMMENT 'ページ英語',
  `page_jp_name` varchar(45) DEFAULT NULL COMMENT 'ページ日本語',
  `page_menu_group_flag` tinyint(4) DEFAULT '0' COMMENT 'メニューグルーブFlag',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`page_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ページ情報';
insert into crm_page(page_en_name,page_jp_name,creator_id,created_time) values ('companyAction','会社情報',1,now());
insert into crm_page(page_en_name,page_jp_name,creator_id,created_time) values ('groupAction','部署情報',1,now());
insert into crm_page(page_en_name,page_jp_name,creator_id,created_time) values ('userAction','ユーザー情報',1,now());
insert into crm_page(page_en_name,page_jp_name,creator_id,created_time) values ('issueAction','受付情報',1,now());

/** モジュールやページ情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_module_page_rel`;
CREATE TABLE `crm_module_page_rel` (
  `module_id` int(11) NOT NULL DEFAULT '0' COMMENT 'モジュールID',
  `page_id` int(11) NOT NULL DEFAULT '0' COMMENT 'ページID',
  PRIMARY KEY (`module_id`,`page_id`),
  KEY `fk_crm_module_page_rel_page_idx` (`page_id`),
  CONSTRAINT `fk_crm_module_page_rel_module` FOREIGN KEY (`module_id`) REFERENCES `crm_system_module` (`module_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_module_page_rel_page` FOREIGN KEY (`page_id`) REFERENCES `crm_page` (`page_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='モジュールやページ情報';
insert into crm_module_page_rel(module_id,page_id) values (1,1);
insert into crm_module_page_rel(module_id,page_id) values (1,2);
insert into crm_module_page_rel(module_id,page_id) values (1,3);
insert into crm_module_page_rel(module_id,page_id) values (3,4);

/** グルーブページ情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_menu_group_page_rel`;
CREATE TABLE `crm_menu_group_page_rel` (
  `menu_group_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'メニューグルーブID',
  `menu_group_name` varchar(45) NOT NULL DEFAULT '' COMMENT 'メニューグルーブ名',
  `menu_group_chidren_id` varchar(100) NOT NULL DEFAULT '' COMMENT 'グルーブページID、例：「1,2,3,...」',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`menu_group_id`),
  KEY `fk_crm_menu_group_page_rel_company_idx` (`company_id`),
  CONSTRAINT `fk_crm_menu_group_page_rel_company` FOREIGN KEY (`company_id`) REFERENCES `crm_company` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='グルーブページ情報';
insert into crm_menu_group_page_rel(menu_group_name,menu_group_chidren_id,company_id,creator_id,created_time) values ('会社管理','1,2,3',1,1,now());
insert into crm_menu_group_page_rel(menu_group_name,menu_group_chidren_id,company_id,creator_id,created_time) values ('会社管理1','1,2,3',2,1,now());
insert into crm_menu_group_page_rel(menu_group_name,menu_group_chidren_id,company_id,creator_id,created_time) values ('会社管理2','1,2,3',3,1,now());

/** メソッド情報テーブルを作成（ロードする際に、プロパティ） */
DROP TABLE IF EXISTS `crm_method`;
CREATE TABLE `crm_method` (
  `method_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'メソッドID',
  `method_en_name` varchar(45) NOT NULL DEFAULT '' COMMENT 'メソッド英語',
  `method_jp_name` varchar(45) DEFAULT NULL COMMENT 'メソッド日本語',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`method_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='メソッド情報';
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('create','新規',1,now());
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('edit','編集',1,now());
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('show','詳細',1,now());
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('save','保存',1,now());
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('update','更新',1,now());
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('delete','削除',1,now());
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('upload','アップロード',1,now());
insert into crm_method(method_en_name,method_jp_name,creator_id,created_time) values ('download','ダウンロード',1,now());

/** ページやメソッド関連情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_page_method_rel`;
CREATE TABLE `crm_page_method_rel` (
  `page_id` int(11) NOT NULL DEFAULT '0' COMMENT 'ページID',
  `method_id` int(11) NOT NULL DEFAULT '0' COMMENT 'メソッドID',
  PRIMARY KEY (`page_id`,`method_id`),
  KEY `fk_crm_page_method_rel_method_idx` (`method_id`),
  CONSTRAINT `fk_crm_page_method_rel_method` FOREIGN KEY (`method_id`) REFERENCES `crm_method` (`method_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_page_method_rel_page` FOREIGN KEY (`page_id`) REFERENCES `crm_page` (`page_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ページやメソッド関連情報';
insert into crm_page_method_rel(page_id,method_id) values (1,1);
insert into crm_page_method_rel(page_id,method_id) values (1,2);
insert into crm_page_method_rel(page_id,method_id) values (1,3);
insert into crm_page_method_rel(page_id,method_id) values (1,4);

insert into crm_page_method_rel(page_id,method_id) values (2,1);
insert into crm_page_method_rel(page_id,method_id) values (2,2);
insert into crm_page_method_rel(page_id,method_id) values (2,3);
insert into crm_page_method_rel(page_id,method_id) values (2,4);
insert into crm_page_method_rel(page_id,method_id) values (2,5);
insert into crm_page_method_rel(page_id,method_id) values (2,6);
insert into crm_page_method_rel(page_id,method_id) values (2,7);
insert into crm_page_method_rel(page_id,method_id) values (2,8);

insert into crm_page_method_rel(page_id,method_id) values (3,1);
insert into crm_page_method_rel(page_id,method_id) values (3,2);
insert into crm_page_method_rel(page_id,method_id) values (3,3);
insert into crm_page_method_rel(page_id,method_id) values (3,4);

insert into crm_page_method_rel(page_id,method_id) values (4,1);
insert into crm_page_method_rel(page_id,method_id) values (4,2);
insert into crm_page_method_rel(page_id,method_id) values (4,3);
insert into crm_page_method_rel(page_id,method_id) values (4,4);
insert into crm_page_method_rel(page_id,method_id) values (4,5);
insert into crm_page_method_rel(page_id,method_id) values (4,6);
insert into crm_page_method_rel(page_id,method_id) values (4,7);
insert into crm_page_method_rel(page_id,method_id) values (4,8);

/** ロール情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_role`;
CREATE TABLE `crm_role` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ロールID',
  `role_name` varchar(45) NOT NULL DEFAULT '' COMMENT 'ロール名',
  `role_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'ロールFlag、１は特集ロール',
  `role_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`role_id`),
  KEY `fk_crm_role_company_idx` (`company_id`),
  CONSTRAINT `fk_crm_role_company` FOREIGN KEY (`company_id`) REFERENCES `crm_company` (`company_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='メソッド情報';
insert into crm_role(role_name,company_id,creator_id,created_time) values ('管理ロール',1,1,now());
insert into crm_role(role_name,company_id,creator_id,created_time) values ('管理ロール1',2,1,now());
insert into crm_role(role_name,company_id,creator_id,created_time) values ('管理ロール2',3,1,now());
insert into crm_role(role_name,company_id,role_flag,creator_id,created_time) values ('特集ロール',1,1,1,now());

/** 会社やロール関連情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_system_use_auth_rel`;
CREATE TABLE `crm_system_use_auth_rel` (
  `role_id` int(11) NOT NULL COMMENT 'ロールID',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `group_member_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0はグルーブ、1はメンバー',
  `group_member_id` int(11) NOT NULL DEFAULT '0' COMMENT 'グループIDまたはメンバーID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`role_id`,`company_id`,`group_member_flag`,`group_member_id`),
  KEY `fk_crm_system_use_auth_rel_company_idx` (`company_id`),
  CONSTRAINT `fk_crm_system_use_auth_rel_company` FOREIGN KEY (`company_id`) REFERENCES `crm_company` (`company_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_system_use_auth_rel_role` FOREIGN KEY (`role_id`) REFERENCES `crm_role` (`role_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会社やロール情報';
insert into crm_system_use_auth_rel(role_id,company_id,group_member_flag,group_member_id,creator_id,created_time) values (1,1,1,1,1,now());
insert into crm_system_use_auth_rel(role_id,company_id,group_member_flag,group_member_id,creator_id,created_time) values (1,2,1,2,1,now());
insert into crm_system_use_auth_rel(role_id,company_id,group_member_flag,group_member_id,creator_id,created_time) values (1,3,1,3,1,now());
insert into crm_system_use_auth_rel(role_id,company_id,group_member_flag,group_member_id,creator_id,created_time) values (1,1,0,1,1,now());
insert into crm_system_use_auth_rel(role_id,company_id,group_member_flag,group_member_id,creator_id,created_time) values (4,2,1,1,1,now());


/** グルーブまたはメンバー使用するロールのページやメソッド情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_role_page_method_rel`;
CREATE TABLE `crm_role_page_method_rel` (
  `role_id` int(11) NOT NULL DEFAULT '0' COMMENT 'ロールID',
  `page_id` int(11) NOT NULL DEFAULT '0' COMMENT 'ページID',
  `method_id` int(11) NOT NULL DEFAULT '0' COMMENT 'メソッドID',
  PRIMARY KEY (`role_id`,`page_id`,`method_id`),
  UNIQUE KEY `role_id` (`role_id`,`page_id`,`method_id`),
  KEY `fk_crm_role_page_method_rel_2_idx` (`page_id`),
  KEY `fk_crm_role_page_method_rel_3_idx` (`method_id`),
  CONSTRAINT `fk_crm_role_page_method_rel_method` FOREIGN KEY (`method_id`) REFERENCES `crm_method` (`method_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_role_page_method_rel_page` FOREIGN KEY (`page_id`) REFERENCES `crm_page` (`page_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_role_page_method_rel_role` FOREIGN KEY (`role_id`) REFERENCES `crm_role` (`role_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='グルーブまたはメンバー使用するロールのページやメソッド情報';
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,1,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,1,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,1,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,1,4);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,2,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,2,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,2,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,2,4);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,3,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,3,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,3,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,3,4);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,4,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,4,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,4,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (1,4,4);

insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,1,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,1,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,1,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,1,4);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,2,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,2,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,2,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,2,4);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,3,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,3,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,3,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,3,4);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,4,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,4,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,4,3);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (2,4,4);

insert into crm_role_page_method_rel(role_id,page_id,method_id) values (4,1,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (4,1,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (4,2,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (4,2,2);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (4,3,1);
insert into crm_role_page_method_rel(role_id,page_id,method_id) values (4,3,2);


/** システムに接続してきたとき、アクセス権限管理テーブル情報 */
DROP VIEW IF EXISTS view_system_auth;
CREATE VIEW view_system_auth AS 
SELECT DISTINCT 
t3.company_id
,t5.member_id
,t2.role_flag
,(SELECT page_en_name FROM crm_page WHERE page_id=t4.page_id LIMIT 0,1) AS page_en_name
,(SELECT method_en_name FROM crm_method WHERE method_id=t4.method_id LIMIT 0,1) AS method_en_name
FROM crm_system_use_auth_rel t1 
INNER JOIN crm_role t2 ON t2.role_id=t1.role_id
INNER JOIN crm_company t3 ON t3.company_id=t1.company_id 
INNER JOIN crm_role_page_method_rel t4 ON t4.role_id=t1.role_id 
LEFT JOIN crm_member t5 ON t1.group_member_flag=1 AND t5.member_id=t1.group_member_id 
WHERE t2.role_deleted=0 AND t3.company_deleted=0 AND t5.member_deleted=0 

UNION 

SELECT DISTINCT 
t3.company_id
,t6.member_id
,t2.role_flag
,(SELECT page_en_name FROM crm_page WHERE page_id=t4.page_id LIMIT 0,1) AS page_en_name
,(SELECT method_en_name FROM crm_method WHERE method_id=t4.method_id LIMIT 0,1) AS method_en_name
FROM crm_system_use_auth_rel t1 
INNER JOIN crm_role t2 ON t2.role_id=t1.role_id
INNER JOIN crm_company t3 ON t3.company_id=t1.company_id 
INNER JOIN crm_role_page_method_rel t4 ON t4.role_id=t1.role_id 
LEFT JOIN crm_group t5 ON t1.group_member_flag=0 AND t5.group_id=t1.group_member_id 
LEFT JOIN crm_member t6 ON t6.group_id=t5.group_id 
WHERE t2.role_deleted=0 AND t3.company_deleted=0 AND t5.group_deleted=0 AND t6.member_deleted=0;

/** システムに接続してきたとき、アクセス権限管理をチェックQUERY
select company_id,member_id,role_flag,page_en_name,concat(',',group_concat(method_en_name),',') from view_system_auth group by company_id,member_id,role_flag,page_en_name;
 */

/** 会社やメンバー画像情報テーブルを作成
DROP TABLE IF EXISTS `crm_attachment_COMPANYID`;
CREATE TABLE `crm_company_user_attachment` (
  `attachment_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ファイルID',
  `attachment_name` varchar(150) NOT NULL DEFAULT '' COMMENT 'ファイル名',
  `attachment_hash_name` varchar(100) DEFAULT '' COMMENT 'DISKに保存された名前',
  `attachment_extension` varchar(10) DEFAULT '' COMMENT 'ファイルの拡張子',
  `attachment_mime_type` varchar(100) DEFAULT '' COMMENT 'Mimeタイプ',
  `attachment_path` varchar(254) DEFAULT '' COMMENT 'ファイルパス',
  `attachment_file_size` varchar(16) DEFAULT '' COMMENT 'ファイルサイズ',
  `attachment_action` int(11) DEFAULT 0 COMMENT 'ページ、アクションID「crm_page」',
  `attachment_target_id` int(11) DEFAULT NULL COMMENT 'ページ、アクションID「crm_issue、crm_contact、。。。」',
  `attachment_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`attachment_id`),
  KEY `attachment_target_id` (`attachment_target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会社やメンバー画像情報';
 */

/** メールサーバテーブル情報 */
DROP TABLE IF EXISTS `crm_mail_server`;
CREATE TABLE `crm_mail_server` (
  `server_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'サーバID',
  `server_name` varchar(100) DEFAULT NULL COMMENT 'サーバ名',
  `server_host` varchar(100) DEFAULT NULL COMMENT 'ドメイン名',
  `server_port` int(11) DEFAULT '25' COMMENT 'ポート',
  `server_auth` enum('true','false') DEFAULT 'false' COMMENT 'SMTP認証',
  `server_ssl` enum('true','false') DEFAULT 'false' COMMENT 'SSL認証',
  `server_charset` varchar(255) DEFAULT 'utf-8' COMMENT '文字コード',
  `server_header` varchar(255) DEFAULT '7bit' COMMENT 'Header文字コード',
  `server_format` varchar(255) DEFAULT 'text' COMMENT 'フォマット',
  `server_same_receive_mail` tinyint(1) DEFAULT '0' COMMENT 'サーバID',
  `server_type` varchar(6) DEFAULT NULL COMMENT 'サーバタイプ「SMTP、IMAP、POP3。。。」',
  `server_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`server_id`),
  KEY `fk_crm_mail_server_company_idx` (`company_id`),
  CONSTRAINT `fk_crm_mail_server_company` FOREIGN KEY (`company_id`) REFERENCES `crm_company` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='メールサーバテーブル情報';
/* 
select page_en_name,page_jp_name from crm_page where page_id not in(1,2,3) union select menu_group_id as page_en_name,menu_group_name as page_jp_name from where company_id=1;
*/

/** 全国住所テーブルを作成 */
DROP TABLE IF EXISTS `crm_zip_code`;
CREATE TABLE `crm_zip_code` (
  `code_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `zip_code` varchar(8) NOT NULL DEFAULT '' COMMENT '郵便番号',
  `city_kana` varchar(50) NOT NULL DEFAULT '' COMMENT '都道府県名',
  `address_kana` varchar(250) DEFAULT NULL COMMENT '市区町村名',
  `district_kana` varchar(200) DEFAULT NULL COMMENT '町域名',
  `city_kannji` varchar(50) NOT NULL DEFAULT '' COMMENT '都道府県名',
  `address_kannji` varchar(250) DEFAULT NULL COMMENT '市区町村名',
  `district_kanj` varchar(200) DEFAULT NULL COMMENT '町域名',
  `locale_code` varchar(3) NOT NULL DEFAULT '' COMMENT 'ローカルコード「ja、vn、。。。」',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT NULL COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT NULL COMMENT '更新日',
  PRIMARY KEY (`code_id`),
  KEY `zip_code` (`zip_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='全国住所テーブル情報';
/** 
LOAD DATA LOCAL INFILE "/home/workspace/crmcloud/data/KEN_ALL_UTF8.CSV"
INTO TABLE crm_zip_code
FIELDS
  TERMINATED BY ','
  OPTIONALLY ENCLOSED BY '"'
LINES
  TERMINATED BY '\r\n'
IGNORE 0 LINES
  (@col1, @col2, @col3, @col4, @col5, @col6, @col7, @col8, @col9, @col10, @col11, @col12, @col13, @col14, @col15)
SET
zip_code = @col3
,city_kana = @col4
,address_kana = @col5
,district_kana = @col6
,city_kannji = @col7
,address_kannji = @col8
,district_kanj = @col9
,locale_code = 'ja'
,creator_id = 1
,created_time = now();
 */


SET foreign_key_checks = 1;
