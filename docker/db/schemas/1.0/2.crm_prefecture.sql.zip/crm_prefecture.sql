-- phpMyAdmin SQL Dump
-- version 3.3.0
-- http://www.phpmyadmin.net
--
-- ホスト: localhost
-- 生成時間: 2016 年 9 月 16 日 13:49
-- サーバのバージョン: 5.6.30
-- PHP のバージョン: 5.6.22

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- データベース: `aleph`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `crm_mst_prefecture`
--

CREATE TABLE IF NOT EXISTS `crm_prefecture` (
  `prefecture_id` int(8) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `prefecture_code` varchar(32) DEFAULT NULL COMMENT 'コード',
  `prefecture_name` varchar(64) DEFAULT NULL COMMENT '名前',
  `prefecture_order` int(8) DEFAULT '0' COMMENT '表示順',
  `prefecture_area_code` varchar(32) DEFAULT NULL COMMENT 'エリアCD',
  `prefecture_area_name` varchar(64) DEFAULT NULL COMMENT 'エリア名',
  `prefecture_locale_code` varchar(3) NOT NULL DEFAULT '' COMMENT 'ローカルコード',
  `prefecture_area_order` int(32) DEFAULT NULL COMMENT 'エリアの表示順',
  `prefecture_is_deleted` tinyint(1) DEFAULT '0' COMMENT '削除フラグ',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`prefecture_id`,prefecture_locale_code),
  KEY `prefecture_name` (`prefecture_name`) USING BTREE,
  KEY `prefecture_code` (`prefecture_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT '全国都道府県情報';

--
-- テーブルのデータをダンプしています `crm_mst_prefecture`
--

INSERT INTO `crm_prefecture` (`prefecture_id`, `prefecture_code`, `prefecture_name`, `prefecture_order`, `prefecture_area_code`, `prefecture_area_name`, `prefecture_area_order`, `creator_id`, `created_time`, `updated_id`, `updated_time`, `prefecture_is_deleted`, `prefecture_locale_code`) VALUES
(1, '1', '北海道', 1, '1', '北海道', 1, NULL, NULL, NULL, NULL, 0, 'ja'),
(2, '2', '青森県', 2, '2', '東北', 2, NULL, NULL, NULL, NULL, 0, 'ja'),
(3, '3', '岩手県', 3, '2', '東北', 3, NULL, NULL, NULL, NULL, 0, 'ja'),
(4, '4', '宮城県', 4, '2', '東北', 4, NULL, NULL, NULL, NULL, 0, 'ja'),
(5, '5', '秋田県', 5, '2', '東北', 5, NULL, NULL, NULL, NULL, 0, 'ja'),
(6, '6', '山形県', 6, '2', '東北', 6, NULL, NULL, NULL, NULL, 0, 'ja'),
(7, '7', '福島県', 7, '2', '東北', 7, NULL, NULL, NULL, NULL, 0, 'ja'),
(8, '8', '茨城県', 8, '3', '関越', 8, NULL, NULL, NULL, NULL, 0, 'ja'),
(9, '9', '栃木県', 9, '3', '関越', 9, NULL, NULL, NULL, NULL, 0, 'ja'),
(10, '10', '群馬県', 10, '3', '関越', 10, NULL, NULL, NULL, NULL, 0, 'ja'),
(11, '11', '新潟県', 11, '3', '関越', 11, NULL, NULL, NULL, NULL, 0, 'ja'),
(12, '12', '埼玉県', 12, '4', '東京', 12, NULL, NULL, NULL, NULL, 0, 'ja'),
(13, '13', '千葉県', 13, '4', '東京', 13, NULL, NULL, NULL, NULL, 0, 'ja'),
(14, '14', '東京都', 14, '4', '東京', 14, NULL, NULL, NULL, NULL, 0, 'ja'),
(15, '15', '神奈川県', 15, '4', '東京', 15, NULL, NULL, NULL, NULL, 0, 'ja'),
(16, '16', '山梨県', 16, '4', '東京', 16, NULL, NULL, NULL, NULL, 0, 'ja'),
(17, '17', '長野県', 17, '4', '東京', 17, NULL, NULL, NULL, NULL, 0, 'ja'),
(18, '18', '岐阜県', 18, '5', '東海', 18, NULL, NULL, NULL, NULL, 0, 'ja'),
(19, '19', '静岡県', 19, '5', '東海', 19, NULL, NULL, NULL, NULL, 0, 'ja'),
(20, '20', '愛知県', 20, '5', '東海', 20, NULL, NULL, NULL, NULL, 0, 'ja'),
(21, '21', '三重県', 21, '5', '東海', 21, NULL, NULL, NULL, NULL, 0, 'ja'),
(22, '22', '富山県', 22, '6', '北陸', 22, NULL, NULL, NULL, NULL, 0, 'ja'),
(23, '23', '石川県', 23, '6', '北陸', 23, NULL, NULL, NULL, NULL, 0, 'ja'),
(24, '24', '福井県', 24, '6', '北陸', 24, NULL, NULL, NULL, NULL, 0, 'ja'),
(25, '25', '滋賀県', 25, '7', '関西', 25, NULL, NULL, NULL, NULL, 0, 'ja'),
(26, '26', '京都府', 26, '7', '関西', 26, NULL, NULL, NULL, NULL, 0, 'ja'),
(27, '27', '大阪府', 27, '7', '関西', 27, NULL, NULL, NULL, NULL, 0, 'ja'),
(28, '28', '兵庫県', 28, '7', '関西', 28, NULL, NULL, NULL, NULL, 0, 'ja'),
(29, '29', '奈良県', 29, '7', '関西', 29, NULL, NULL, NULL, NULL, 0, 'ja'),
(30, '30', '和歌山県', 30, '7', '関西', 30, NULL, NULL, NULL, NULL, 0, 'ja'),
(31, '31', '鳥取県', 31, '8', '中国', 31, NULL, NULL, NULL, NULL, 0, 'ja'),
(32, '32', '島根県', 32, '8', '中国', 32, NULL, NULL, NULL, NULL, 0, 'ja'),
(33, '33', '岡山県', 33, '8', '中国', 33, NULL, NULL, NULL, NULL, 0, 'ja'),
(34, '34', '広島県', 34, '8', '中国', 34, NULL, NULL, NULL, NULL, 0, 'ja'),
(35, '35', '山口県', 35, '8', '中国', 35, NULL, NULL, NULL, NULL, 0, 'ja'),
(36, '36', '徳島県', 36, '9', '四国', 36, NULL, NULL, NULL, NULL, 0, 'ja'),
(37, '37', '香川県', 37, '9', '四国', 37, NULL, NULL, NULL, NULL, 0, 'ja'),
(38, '38', '愛媛県', 38, '9', '四国', 38, NULL, NULL, NULL, NULL, 0, 'ja'),
(39, '39', '高知県', 39, '9', '四国', 39, NULL, NULL, NULL, NULL, 0, 'ja'),
(40, '40', '福岡県', 40, '10', '九州', 40, NULL, NULL, NULL, NULL, 0, 'ja'),
(41, '41', '佐賀県', 41, '10', '九州', 41, NULL, NULL, NULL, NULL, 0, 'ja'),
(42, '42', '長崎県', 42, '10', '九州', 42, NULL, NULL, NULL, NULL, 0, 'ja'),
(43, '43', '熊本県', 43, '10', '九州', 43, NULL, NULL, NULL, NULL, 0, 'ja'),
(44, '44', '大分県', 44, '10', '九州', 44, NULL, NULL, NULL, NULL, 0, 'ja'),
(45, '45', '宮崎県', 45, '10', '九州', 45, NULL, NULL, NULL, NULL, 0, 'ja'),
(46, '46', '鹿児島県', 46, '10', '九州', 46, NULL, NULL, NULL, NULL, 0, 'ja'),
(47, '47', '沖縄県', 47, '10', '九州', 47, NULL, NULL, NULL, NULL, 0, 'ja'),
(48, '1', '北海道', 1, '1', '北海道', 1, NULL, NULL, NULL, NULL, 0, 'ja'),
(49, '2', '青森県', 2, '2', '東北', 2, NULL, NULL, NULL, NULL, 0, 'ja'),
(50, '3', '岩手県', 3, '2', '東北', 3, NULL, NULL, NULL, NULL, 0, 'ja'),
(51, '4', '宮城県', 4, '2', '東北', 4, NULL, NULL, NULL, NULL, 0, 'ja'),
(52, '5', '秋田県', 5, '2', '東北', 5, NULL, NULL, NULL, NULL, 0, 'ja'),
(53, '6', '山形県', 6, '2', '東北', 6, NULL, NULL, NULL, NULL, 0, 'ja'),
(54, '7', '福島県', 7, '2', '東北', 7, NULL, NULL, NULL, NULL, 0, 'ja'),
(55, '8', '茨城県', 8, '3', '関越', 8, NULL, NULL, NULL, NULL, 0, 'ja'),
(56, '9', '栃木県', 9, '3', '関越', 9, NULL, NULL, NULL, NULL, 0, 'ja'),
(57, '10', '群馬県', 10, '3', '関越', 10, NULL, NULL, NULL, NULL, 0, 'ja'),
(58, '11', '新潟県', 11, '3', '関越', 11, NULL, NULL, NULL, NULL, 0, 'ja'),
(59, '12', '埼玉県', 12, '4', '東京', 12, NULL, NULL, NULL, NULL, 0, 'ja'),
(60, '13', '千葉県', 13, '4', '東京', 13, NULL, NULL, NULL, NULL, 0, 'ja'),
(61, '14', '東京都', 14, '4', '東京', 14, NULL, NULL, NULL, NULL, 0, 'ja'),
(62, '15', '神奈川県', 15, '4', '東京', 15, NULL, NULL, NULL, NULL, 0, 'ja'),
(63, '16', '山梨県', 16, '4', '東京', 16, NULL, NULL, NULL, NULL, 0, 'ja'),
(64, '17', '長野県', 17, '4', '東京', 17, NULL, NULL, NULL, NULL, 0, 'ja'),
(65, '18', '岐阜県', 18, '5', '東海', 18, NULL, NULL, NULL, NULL, 0, 'ja'),
(66, '19', '静岡県', 19, '5', '東海', 19, NULL, NULL, NULL, NULL, 0, 'ja'),
(67, '20', '愛知県', 20, '5', '東海', 20, NULL, NULL, NULL, NULL, 0, 'ja'),
(68, '21', '三重県', 21, '5', '東海', 21, NULL, NULL, NULL, NULL, 0, 'ja'),
(69, '22', '富山県', 22, '6', '北陸', 22, NULL, NULL, NULL, NULL, 0, 'ja'),
(70, '23', '石川県', 23, '6', '北陸', 23, NULL, NULL, NULL, NULL, 0, 'ja'),
(71, '24', '福井県', 24, '6', '北陸', 24, NULL, NULL, NULL, NULL, 0, 'ja'),
(72, '25', '滋賀県', 25, '7', '関西', 25, NULL, NULL, NULL, NULL, 0, 'ja'),
(73, '26', '京都府', 26, '7', '関西', 26, NULL, NULL, NULL, NULL, 0, 'ja'),
(74, '27', '大阪府', 27, '7', '関西', 27, NULL, NULL, NULL, NULL, 0, 'ja'),
(75, '28', '兵庫県', 28, '7', '関西', 28, NULL, NULL, NULL, NULL, 0, 'ja'),
(76, '29', '奈良県', 29, '7', '関西', 29, NULL, NULL, NULL, NULL, 0, 'ja'),
(77, '30', '和歌山県', 30, '7', '関西', 30, NULL, NULL, NULL, NULL, 0, 'ja'),
(78, '31', '鳥取県', 31, '8', '中国', 31, NULL, NULL, NULL, NULL, 0, 'ja'),
(79, '32', '島根県', 32, '8', '中国', 32, NULL, NULL, NULL, NULL, 0, 'ja'),
(80, '33', '岡山県', 33, '8', '中国', 33, NULL, NULL, NULL, NULL, 0, 'ja'),
(81, '34', '広島県', 34, '8', '中国', 34, NULL, NULL, NULL, NULL, 0, 'ja'),
(82, '35', '山口県', 35, '8', '中国', 35, NULL, NULL, NULL, NULL, 0, 'ja'),
(83, '36', '徳島県', 36, '9', '四国', 36, NULL, NULL, NULL, NULL, 0, 'ja'),
(84, '37', '香川県', 37, '9', '四国', 37, NULL, NULL, NULL, NULL, 0, 'ja'),
(85, '38', '愛媛県', 38, '9', '四国', 38, NULL, NULL, NULL, NULL, 0, 'ja'),
(86, '39', '高知県', 39, '9', '四国', 39, NULL, NULL, NULL, NULL, 0, 'ja'),
(87, '40', '福岡県', 40, '10', '九州', 40, NULL, NULL, NULL, NULL, 0, 'ja'),
(88, '41', '佐賀県', 41, '10', '九州', 41, NULL, NULL, NULL, NULL, 0, 'ja'),
(89, '42', '長崎県', 42, '10', '九州', 42, NULL, NULL, NULL, NULL, 0, 'ja'),
(90, '43', '熊本県', 43, '10', '九州', 43, NULL, NULL, NULL, NULL, 0, 'ja'),
(91, '44', '大分県', 44, '10', '九州', 44, NULL, NULL, NULL, NULL, 0, 'ja'),
(92, '45', '宮崎県', 45, '10', '九州', 45, NULL, NULL, NULL, NULL, 0, 'ja'),
(93, '46', '鹿児島県', 46, '10', '九州', 46, NULL, NULL, NULL, NULL, 0, 'ja'),
(94, '47', '沖縄県', 47, '100', '九州1', 47, NULL, NULL, NULL, NULL, 0, 'ja');
