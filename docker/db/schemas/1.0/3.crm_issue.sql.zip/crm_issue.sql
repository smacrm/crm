SET foreign_key_checks = 0;

/** 受付情報フォマートテーブル情報を作成 */
DROP TABLE IF EXISTS `crm_issue`;
CREATE TABLE `crm_issue` (
  `issue_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '受付ID',
  `issue_code` varchar(16) NOT NULL COMMENT '受付番号',
  `issue_receive_id` varchar(32) DEFAULT NULL COMMENT '受付方法ID',
  `issue_public` tinyint(4) DEFAULT '0' COMMENT '「公開、非公開」0は公開',
  `issue_receive_person_id` varchar(64) DEFAULT NULL COMMENT '受付者ID',
  `issue_status_id` varchar(64) DEFAULT NULL COMMENT '進捗状況ID',
  `issue_receive_date` datetime DEFAULT NULL COMMENT '受付日（年月日）',
  `issue_business_status` tinyint(1) DEFAULT NULL COMMENT '進捗状況ID',
  `issue_closed_date` datetime DEFAULT NULL COMMENT '完了日時',
  `issue_req_large_id` int(11) DEFAULT NULL COMMENT '申出大ID',
  `issue_req_medium_id` int(11) DEFAULT NULL COMMENT '申出中ID',
  `issue_req_small_id` int(11) DEFAULT NULL COMMENT '申出メモ',
  `issue_req_memo` varchar(2000) DEFAULT NULL COMMENT '申出メモ',
  `issue_keyword_id` varchar(100) DEFAULT NULL COMMENT 'キーワード「1,2,3,4,5,。。。」',
  `issue_product_large_id` int(11) DEFAULT NULL COMMENT '商品大ID',
  `issue_product_medium_id` int(11) DEFAULT NULL COMMENT '商品中ID',
  `issue_product_small_id` int(11) DEFAULT NULL COMMENT '商品小ID',
  `issue_product_memo` varchar(2000) DEFAULT NULL COMMENT '商品メモ',
  `issue_content_ask` varchar(2000) DEFAULT NULL COMMENT '申出内容',
  `issue_deleted` tinyint(1) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='受付情報フォマートテーブル情報、注意：各受付情報は「crm_issue_会社ID」に使用';

/** 顧客情報フォマートテーブル情報を作成 */
DROP TABLE IF EXISTS `crm_customer`;
CREATE TABLE `crm_customer` (
  cust_id int(11) NOT NULL AUTO_INCREMENT COMMENT '顧客ID',
  cust_special_flag tinyint NOT NULL DEFAULT 0 COMMENT '１は特殊顧客',
  cust_cooperation_id int DEFAULT NULL COMMENT '申出者種別ID',
  cust_first_hira varchar(70) DEFAULT NULL COMMENT '氏(カナ)',
  cust_family_hira varchar(70) DEFAULT NULL COMMENT '名(カナ)',
  cust_first_kana varchar(70) DEFAULT NULL COMMENT '氏(カナ)',
  cust_family_kana varchar(70) DEFAULT NULL COMMENT '名(カナ)',
  cust_sex_id int(11) DEFAULT NULL COMMENT '性別',
  cust_age_id int(11) DEFAULT NULL COMMENT '年代',
  `cust_post` varchar(8) DEFAULT NULL COMMENT '郵便番号',
  `cust_city` int(11) DEFAULT NULL COMMENT '都道府県',
  `cust_address` varchar(150) DEFAULT NULL COMMENT '住所',
  `cust_address_kana` varchar(200) DEFAULT NULL COMMENT '住所カナ',
  cust_memo varchar(2000) DEFAULT NULL COMMENT 'メモ',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `cust_deleted` tinyint(1) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='顧客情報フォマートテーブル情報、注意：各顧客情報は「crm_cust_target_info_会社ID」に使用';

/** 受付または顧客関連フォマートテーブル情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_issue_cust_rel`;
CREATE TABLE `crm_issue_cust_rel` (
  `issue_id` int(11) NOT NULL DEFAULT '0' COMMENT '受付ID',
  `cust_id` int(11) NOT NULL DEFAULT '0' COMMENT '顧客ID',
  PRIMARY KEY (`issue_id`,`cust_id`),
  CONSTRAINT `fk_crm_issue_cust_rel_issue` FOREIGN KEY (`issue_id`) REFERENCES `crm_issue` (`issue_id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_crm_issue_cust_rel_cust` FOREIGN KEY (`cust_id`) REFERENCES `crm_customer` (`cust_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会社使用可能モジュール情報';

/** 顧客「メール、TEL、FAX」フォマート情報を作成 */
DROP TABLE IF EXISTS `crm_cust_target_info`;
CREATE TABLE `crm_cust_target_info` (
  `target_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'タゲットID',
  `cust_id` int(11) NOT NULL DEFAULT '0' COMMENT '顧客ID',
  `cust_flag_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '「１はメール、２は電話番号、３は携帯番号、４はFAX」、。。。。',
  `cust_target_data` varchar(120) DEFAULT NULL COMMENT '各タイプのデータ',
  `cust_target_deleted` tinyint(4) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `cust_deleted` tinyint(1) DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  PRIMARY KEY (`target_id`),
  INDEX (cust_id,cust_flag_type),
  CONSTRAINT `fk_crm_cust_target_info_cust` FOREIGN KEY (`cust_id`) REFERENCES `crm_customer` (`cust_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='顧客「メール、TEL、MOBILE、FAX、。。。。」情報、注意：各顧客は「crm_cust_target_info_会社ID」に使用';

/** 受付、対応内容、調査内容、。。。画像フォマート情報テーブルを作成 */
DROP TABLE IF EXISTS `crm_attachment`;
CREATE TABLE `crm_attachment` (
  `attachment_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ファイルID',
  `attachment_name` varchar(150) NOT NULL DEFAULT '' COMMENT 'ファイル名',
  `attachment_hash_name` varchar(100) DEFAULT '' COMMENT 'DISKに保存された名前',
  `attachment_extension` varchar(10) DEFAULT '' COMMENT 'ファイルの拡張子',
  `attachment_mime_type` varchar(100) DEFAULT '' COMMENT 'Mimeタイプ',
  `attachment_path` varchar(254) DEFAULT '' COMMENT 'ファイルパス',
  `attachment_file_size` varchar(16) DEFAULT '' COMMENT 'ファイルサイズ',
  `attachment_page_id` varchar(30) DEFAULT 0 COMMENT '受付、対応内容、調査内容の英語名「１、２、３、。。。」',
  `attachment_target_id` int(11) DEFAULT NULL COMMENT '受付、対応内容、調査内容ID「issue_id、detail_id、。。。」',
  `attachment_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '存在フラグ、１は削除',
  `company_id` int(11) NOT NULL DEFAULT '0' COMMENT '会社ID',
  `creator_id` int(11) DEFAULT NULL COMMENT '作成者',
  `created_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日',
  `updated_id` int(11) DEFAULT NULL COMMENT '更新者',
  `updated_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日',
  PRIMARY KEY (`attachment_id`,attachment_page_id,attachment_target_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='受付、対応内容、調査内容、。。。画像フォマート情報、注意：各情報は「crm_attachment_会社ID」に使用';

SET foreign_key_checks = 1;

